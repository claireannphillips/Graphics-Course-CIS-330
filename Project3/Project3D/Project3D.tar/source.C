#include "image.h"
#include "source.h"

//data member that is an image
Image * source::GetOutput() {
	return &img;
}

